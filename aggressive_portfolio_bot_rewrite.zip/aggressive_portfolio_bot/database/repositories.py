import json
import logging
import sqlite3
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

logger = logging.getLogger("aggressive_portfolio_bot.database.repositories")


@dataclass
class ActiveTrade:
    id: int
    symbol: str
    side: str
    strategy: str
    status: str
    entry_price: float
    stop_loss: float
    take_profit: float
    trade_horizon: str | None = None
    holding_style: str | None = None


class TradeRepository:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.conn.row_factory = sqlite3.Row
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS active_trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                strategy TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'OPEN',
                entry_price REAL NOT NULL,
                stop_loss REAL NOT NULL,
                take_profit REAL NOT NULL,
                trade_horizon TEXT,
                holding_style TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS pending_trade_alerts (
                trade_id TEXT PRIMARY KEY,
                payload_json TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                status TEXT NOT NULL DEFAULT 'PENDING'
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS scanner_cache (
                cache_key TEXT PRIMARY KEY,
                payload_json TEXT NOT NULL,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        self.conn.commit()

    def get_open_trades(self) -> List[ActiveTrade]:
        cur = self.conn.cursor()
        cur.execute(
            """
            SELECT id, symbol, side, strategy, status, entry_price, stop_loss, take_profit,
                   trade_horizon, holding_style
            FROM active_trades
            WHERE status = 'OPEN'
            ORDER BY created_at ASC
            """
        )
        rows = cur.fetchall()
        return [
            ActiveTrade(
                id=row["id"],
                symbol=row["symbol"],
                side=row["side"],
                strategy=row["strategy"],
                status=row["status"],
                entry_price=float(row["entry_price"]),
                stop_loss=float(row["stop_loss"]),
                take_profit=float(row["take_profit"]),
                trade_horizon=row["trade_horizon"],
                holding_style=row["holding_style"],
            )
            for row in rows
        ]

    def insert_trade_alert(self, trade_id: str, payload: Dict[str, Any]) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            INSERT OR REPLACE INTO pending_trade_alerts (trade_id, payload_json, status)
            VALUES (?, ?, 'PENDING')
            """,
            (trade_id, json.dumps(payload)),
        )
        self.conn.commit()

    def get_pending_alert_by_id(self, trade_id: str) -> Optional[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute(
            """
            SELECT payload_json
            FROM pending_trade_alerts
            WHERE trade_id = ? AND status = 'PENDING'
            """,
            (trade_id,),
        )
        row = cur.fetchone()
        if not row:
            return None
        return json.loads(row["payload_json"])

    def update_alert_status(self, trade_id: str, status: str) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            UPDATE pending_trade_alerts
            SET status = ?
            WHERE trade_id = ?
            """,
            (status, trade_id),
        )
        self.conn.commit()

    def add_active_trade(self, payload: Dict[str, Any]) -> int:
        cur = self.conn.cursor()
        cur.execute(
            """
            INSERT INTO active_trades (
                symbol, side, strategy, status, entry_price, stop_loss, take_profit,
                trade_horizon, holding_style
            )
            VALUES (?, ?, ?, 'OPEN', ?, ?, ?, ?, ?)
            """,
            (
                payload.get("symbol", "UNKNOWN"),
                payload.get("side", "N/A"),
                payload.get("strategy", "Unknown"),
                float(payload.get("entry_price", 0.0)),
                float(payload.get("stop_loss", 0.0)),
                float(payload.get("take_profit", 0.0)),
                payload.get("trade_horizon"),
                payload.get("holding_style"),
            ),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def update_trade_status(self, trade_id: int, status: str) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            UPDATE active_trades
            SET status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (status, trade_id),
        )
        self.conn.commit()

    def cache_scan_result(self, cache_key: str, payload: Dict[str, Any]) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            INSERT OR REPLACE INTO scanner_cache (cache_key, payload_json, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
            """,
            (cache_key, json.dumps(payload)),
        )
        self.conn.commit()

    def get_cached_scan_result(self, cache_key: str) -> Optional[Dict[str, Any]]:
        cur = self.conn.cursor()
        cur.execute("SELECT payload_json FROM scanner_cache WHERE cache_key = ?", (cache_key,))
        row = cur.fetchone()
        if not row:
            return None
        return json.loads(row["payload_json"])
