import logging
from typing import Any, Dict, List

import pandas as pd
import pandas_ta as ta

logger = logging.getLogger("aggressive_portfolio_bot.strategies.trend_following")


class TrendFollowingStrategy:
    def __init__(self, adx_threshold: int = 25):
        self.adx_threshold = adx_threshold

    def analyze(self, df: pd.DataFrame, symbol: str) -> Dict[str, Any]:
        required_cols: List[str] = ["high", "low", "close"]
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            return {"symbol": symbol, "signal": "INVALID_DATA", "reason": f"Missing columns: {missing_cols}"}

        clean_df = df[required_cols].dropna().copy()
        if len(clean_df) < 50:
            return {"symbol": symbol, "signal": "INSUFFICIENT_DATA"}

        clean_df.ta.ema(length=9, append=True)
        clean_df.ta.sma(length=21, append=True)
        clean_df.ta.adx(length=14, append=True)

        latest = clean_df.iloc[-1]
        close_price = float(latest["close"])
        ema_9 = latest.get("EMA_9")
        sma_21 = latest.get("SMA_21")
        adx_14 = latest.get("ADX_14")

        if pd.isna(ema_9) or pd.isna(sma_21) or pd.isna(adx_14):
            return {"symbol": symbol, "signal": "INVALID_DATA", "reason": "Indicator values unavailable"}

        signal = "WAIT"
        if adx_14 > self.adx_threshold:
            if ema_9 > sma_21 and close_price > ema_9:
                signal = "LONG_TREND"
            elif ema_9 < sma_21 and close_price < ema_9:
                signal = "SHORT_TREND"

        return {
            "symbol": symbol,
            "signal": signal,
            "adx_strength": round(float(adx_14), 2),
            "ema_9": round(float(ema_9), 2),
            "sma_21": round(float(sma_21), 2),
            "close_price": round(close_price, 2),
        }
