import logging
from typing import List

from aggressive_portfolio_bot.database.repositories import TradeRepository
from aggressive_portfolio_bot.telegram_bot.formatters import format_daily_report

logger = logging.getLogger("aggressive_portfolio_bot.services.midday")


class MiddayService:
    def __init__(self, telegram_app, chat_id: str, repo: TradeRepository, news_scraper, rh_client, prop_client):
        self.telegram_app = telegram_app
        self.chat_id = chat_id
        self.repo = repo
        self.news_scraper = news_scraper
        self.rh_client = rh_client
        self.prop_client = prop_client

    async def run(self) -> None:
        logger.info("Initiating 10:00 AM Mid-Day Review Workflow...")
        bullets: List[str] = []

        headlines = await self.news_scraper.fetch_market_news()
        sentiment_data = self.news_scraper.analyze_sentiment(headlines)
        market_sentiment = sentiment_data.get("sentiment", "Neutral")

        bullets.append(f"Intra-day Market Sentiment: {market_sentiment}")
        if market_sentiment == "Bearish":
            bullets.append("Warning: Broad market sentiment has shifted Bearish since the open.")

        rh_positions = self.rh_client.get_active_positions()
        open_stocks = rh_positions.get("stocks", [])
        open_options = rh_positions.get("options", [])

        if not open_stocks and not open_options:
            bullets.append("Robinhood: No active options or equity positions to manage.")
        else:
            bullets.append(f"Robinhood Active: Tracking {len(open_stocks)} equities and {len(open_options)} options contracts.")

        prop_orders = await self.prop_client.get_active_orders()
        if not prop_orders:
            bullets.append("Futures (Prop Firm): No active working orders.")
        else:
            bullets.append(f"Futures (Prop Firm): Tracking {len(prop_orders)} active orders.")

        db_trades = self.repo.get_open_trades()
        if db_trades:
            bullets.append("Bot-Managed Trades Status:")
            for trade in db_trades:
                bullets.append(
                    f"{trade.symbol} ({trade.side}) | Entry: ${trade.entry_price:.2f} | "
                    f"SL: ${trade.stop_loss:.2f} | TP: ${trade.take_profit:.2f} | "
                    f"{trade.trade_horizon or 'UNCLASSIFIED'}"
                )
        else:
            bullets.append("Bot-Managed Trades: No active bot-managed trades are open.")

        report_text = format_daily_report(title="☀️ 10:00 AM Mid-Day Review", bullets=bullets)
        await self.telegram_app.bot.send_message(
            chat_id=self.chat_id,
            text=report_text,
            parse_mode="HTML",
        )
        logger.info("Mid-Day Report sent to Telegram.")
