import logging
import uuid
from datetime import date
from typing import List

from aggressive_portfolio_bot.database.repositories import TradeRepository
from aggressive_portfolio_bot.telegram_bot.formatters import format_daily_report, format_trade_alert
from aggressive_portfolio_bot.telegram_bot.keyboards import build_trade_keyboard

logger = logging.getLogger("aggressive_portfolio_bot.services.premarket")


class PremarketService:
    def __init__(self, telegram_app, chat_id: str, repo: TradeRepository, news_scraper, market_data_client, router):
        self.telegram_app = telegram_app
        self.chat_id = chat_id
        self.repo = repo
        self.news_scraper = news_scraper
        self.market_data_client = market_data_client
        self.router = router

    async def fetch_economic_report(self) -> str:
        return "No major Fed speakers scheduled. Review morning macro calendar before the open."

    async def get_daily_tickers(self) -> List[str]:
        return ["SPY", "QQQ", "TSLA", "NVDA", "AMD"]

    async def run(self) -> None:
        logger.info("Initiating 5:30 AM Pre-Market Workflow...")
        bullets: List[str] = []

        econ_notes = await self.fetch_economic_report()
        bullets.append(f"Economic Calendar: {econ_notes}")

        headlines = await self.news_scraper.fetch_market_news()
        sentiment_data = self.news_scraper.analyze_sentiment(headlines)
        market_sentiment = sentiment_data.get("sentiment", "Neutral")
        bullets.append(f"Market Sentiment: {market_sentiment}")

        tickers = await self.get_daily_tickers()
        bullets.append(f"Ticker Dig Initiated For: {', '.join(tickers)}")

        day_trades: List[str] = []
        swing_trades: List[str] = []
        valid_trade_alerts = []

        today = date.today().isoformat()

        for symbol in tickers:
            df = await self.market_data_client.get_historical_data(
                symbol=symbol,
                multiplier=5,
                timespan="minute",
                start_date=today,
                end_date=today,
            )

            if df.empty:
                continue

            payload = self.router.evaluate_ticker(symbol, df)
            if not payload:
                continue

            if payload.get("trade_horizon") == "DAY_TRADE":
                day_trades.append(symbol)
            else:
                swing_trades.append(symbol)

            trade_id = uuid.uuid4().hex[:12]
            payload["trade_id"] = trade_id
            self.repo.insert_trade_alert(trade_id, payload)
            valid_trade_alerts.append(payload)

        if day_trades:
            bullets.append(f"Day Trade Watchlist: {', '.join(day_trades)}")
        if swing_trades:
            bullets.append(f"Swing Trade Watchlist: {', '.join(swing_trades)}")
        if not day_trades and not swing_trades:
            bullets.append("No qualified setups found in the current pre-market scan.")

        report_text = format_daily_report(title="🌅 5:30 AM Pre-Market Report", bullets=bullets)
        await self.telegram_app.bot.send_message(
            chat_id=self.chat_id,
            text=report_text,
            parse_mode="HTML",
        )
        logger.info("Pre-Market Report sent to Telegram.")

        for alert in valid_trade_alerts:
            alert_text = format_trade_alert(alert)
            keyboard = build_trade_keyboard(alert["trade_id"])
            await self.telegram_app.bot.send_message(
                chat_id=self.chat_id,
                text=alert_text,
                reply_markup=keyboard,
                parse_mode="HTML",
            )
