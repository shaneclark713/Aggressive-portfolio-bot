import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import gspread
from google.oauth2.service_account import Credentials

logger = logging.getLogger("aggressive_portfolio_bot.ledger.sheets_client")


class GoogleSheetsLedger:
    def __init__(self, credentials_path: str, spreadsheet_id: str, worksheet_name: str = "Trades"):
        self.credentials_path = credentials_path
        self.spreadsheet_id = spreadsheet_id
        self.worksheet_name = worksheet_name
        self.scopes = [
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive",
        ]
        self.client: Optional[gspread.Client] = None
        self.sheet = None

    def connect(self) -> bool:
        try:
            creds = Credentials.from_service_account_file(self.credentials_path, scopes=self.scopes)
            self.client = gspread.authorize(creds)
            workbook = self.client.open_by_key(self.spreadsheet_id)
            self.sheet = workbook.worksheet(self.worksheet_name)
            logger.info("Successfully connected to Google Sheets Ledger.")
            return True
        except Exception as e:
            logger.exception("Failed to connect to Google Sheets: %s", e)
            return False

    @staticmethod
    def _to_float(value: Any, default: float = 0.0) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    def log_closed_trade(self, trade_data: Dict[str, Any]) -> bool:
        if not self.sheet:
            logger.warning("Cannot log trade: Google Sheets client not connected.")
            return False

        try:
            row_data = [
                datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
                str(trade_data.get("symbol", "UNKNOWN")),
                str(trade_data.get("side", "N/A")),
                str(trade_data.get("strategy", "Unknown")),
                round(self._to_float(trade_data.get("entry_price")), 2),
                round(self._to_float(trade_data.get("exit_price")), 2),
                round(self._to_float(trade_data.get("pnl")), 2),
                round(self._to_float(trade_data.get("actual_rr")), 2),
            ]
            self.sheet.append_row(row_data, value_input_option="RAW")
            logger.info("Successfully logged %s trade to Google Sheets.", trade_data.get("symbol", "UNKNOWN"))
            return True
        except Exception as e:
            logger.exception("Failed to append trade to Google Sheets: %s", e)
            return False
