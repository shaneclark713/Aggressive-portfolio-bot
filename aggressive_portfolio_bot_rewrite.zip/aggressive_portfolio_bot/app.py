import asyncio
import logging
import os
import signal
import sqlite3
from dataclasses import dataclass
from zoneinfo import ZoneInfo

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from telegram.ext import Application, ApplicationBuilder, CallbackQueryHandler, CommandHandler

from aggressive_portfolio_bot.brokers.prop_firm import PropFirmClient
from aggressive_portfolio_bot.brokers.robinhood import RobinhoodClient
from aggressive_portfolio_bot.core.context import AppContext
from aggressive_portfolio_bot.data.market_data import MarketDataClient
from aggressive_portfolio_bot.data.news_data import NewsScraper
from aggressive_portfolio_bot.database.repositories import TradeRepository
from aggressive_portfolio_bot.ledger.sheets_client import GoogleSheetsLedger
from aggressive_portfolio_bot.services.midday_service import MiddayService
from aggressive_portfolio_bot.services.postmarket_service import PostmarketService
from aggressive_portfolio_bot.services.premarket_service import PremarketService
from aggressive_portfolio_bot.strategies.router import StrategyRouter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("aggressive_portfolio_bot")


@dataclass
class Settings:
    telegram_token: str
    telegram_chat_id: str
    timezone: str = "America/Phoenix"
    sqlite_path: str = "trading_bot.sqlite3"
    news_api_key: str = ""
    market_data_api_key: str = ""
    rh_username: str = ""
    rh_password: str = ""
    rh_mfa_secret: str | None = None
    prop_api_key: str = ""
    prop_api_secret: str = ""
    prop_base_url: str = ""
    google_credentials_path: str | None = None
    google_spreadsheet_id: str | None = None


def load_settings() -> Settings:
    telegram_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    telegram_chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()

    if not telegram_token:
        raise ValueError("Missing TELEGRAM_BOT_TOKEN in environment.")
    if not telegram_chat_id:
        raise ValueError("Missing TELEGRAM_CHAT_ID in environment.")

    return Settings(
        telegram_token=telegram_token,
        telegram_chat_id=telegram_chat_id,
        timezone=os.getenv("APP_TIMEZONE", "America/Phoenix").strip(),
        sqlite_path=os.getenv("SQLITE_PATH", "trading_bot.sqlite3").strip(),
        news_api_key=os.getenv("FINNHUB_API_KEY", "").strip(),
        market_data_api_key=os.getenv("POLYGON_API_KEY", "").strip(),
        rh_username=os.getenv("ROBINHOOD_USERNAME", "").strip(),
        rh_password=os.getenv("ROBINHOOD_PASSWORD", "").strip(),
        rh_mfa_secret=os.getenv("ROBINHOOD_MFA_SECRET", "").strip() or None,
        prop_api_key=os.getenv("PROP_API_KEY", "").strip(),
        prop_api_secret=os.getenv("PROP_API_SECRET", "").strip(),
        prop_base_url=os.getenv("PROP_BASE_URL", "").strip(),
        google_credentials_path=os.getenv("GOOGLE_CREDENTIALS_PATH", "").strip() or None,
        google_spreadsheet_id=os.getenv("GOOGLE_SPREADSHEET_ID", "").strip() or None,
    )


async def start_command(update, context) -> None:
    await update.message.reply_text("Trading bot online. Scheduler is active and listening for callbacks.")


async def handle_trade_action(update, context) -> None:
    query = update.callback_query
    await query.answer()

    payload = query.data or ""
    action, _, trade_id = payload.partition("|")
    repo: TradeRepository = context.application.bot_data["trade_repo"]

    trade_payload = repo.get_pending_alert_by_id(trade_id)
    if not trade_payload:
        await query.edit_message_text("Trade alert not found or already processed.")
        return

    action_map = {"a": "APPROVED", "p": "PAPER", "r": "REJECTED"}
    status = action_map.get(action, "UNKNOWN")
    repo.update_alert_status(trade_id, status)

    if status == "APPROVED":
        repo.add_active_trade(trade_payload)

    await query.edit_message_text(
        text=(
            f"Action received.\n"
            f"Trade ID: {trade_id}\n"
            f"Decision: {status}\n"
            f"Symbol: {trade_payload.get('symbol', 'UNKNOWN')}\n"
            f"Strategy: {trade_payload.get('strategy', 'Unknown')}"
        )
    )


def build_scheduler(
    timezone: str,
    premarket_service: PremarketService,
    midday_service: MiddayService,
    postmarket_service: PostmarketService,
) -> AsyncIOScheduler:
    tz = ZoneInfo(timezone)
    scheduler = AsyncIOScheduler(timezone=tz)

    scheduler.add_job(
        premarket_service.run,
        trigger=CronTrigger(hour=5, minute=30, timezone=tz),
        id="premarket_job",
        name="5:30 AM Pre-Market Workflow",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
        misfire_grace_time=300,
    )
    scheduler.add_job(
        midday_service.run,
        trigger=CronTrigger(hour=10, minute=0, timezone=tz),
        id="midday_job",
        name="10:00 AM Mid-Day Review",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
        misfire_grace_time=300,
    )
    scheduler.add_job(
        postmarket_service.run,
        trigger=CronTrigger(hour=21, minute=0, timezone=tz),
        id="postmarket_job",
        name="9:00 PM Post-Market Workflow",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
        misfire_grace_time=300,
    )

    return scheduler


async def run_app() -> None:
    settings = load_settings()
    logger.info("Loaded settings. Using timezone: %s", settings.timezone)

    db_conn = sqlite3.connect(settings.sqlite_path)
    trade_repo = TradeRepository(db_conn)

    telegram_app = ApplicationBuilder().token(settings.telegram_token).build()
    telegram_app.bot_data["trade_repo"] = trade_repo
    telegram_app.add_handler(CommandHandler("start", start_command))
    telegram_app.add_handler(CallbackQueryHandler(handle_trade_action))

    news_scraper = NewsScraper(api_key=settings.news_api_key)
    market_data_client = MarketDataClient(api_key=settings.market_data_api_key)
    rh_client = RobinhoodClient(
        username=settings.rh_username,
        password=settings.rh_password,
        mfa_secret=settings.rh_mfa_secret,
        store_session=False,
    )
    prop_client = PropFirmClient(
        api_key=settings.prop_api_key,
        api_secret=settings.prop_api_secret,
        base_url=settings.prop_base_url,
    )
    router = StrategyRouter()

    sheets_ledger = None
    if settings.google_credentials_path and settings.google_spreadsheet_id:
        sheets_ledger = GoogleSheetsLedger(
            credentials_path=settings.google_credentials_path,
            spreadsheet_id=settings.google_spreadsheet_id,
            worksheet_name="Trades",
        )
        sheets_ledger.connect()

    await news_scraper.connect()
    await market_data_client.connect()
    await prop_client.connect()
    if settings.rh_username and settings.rh_password:
        rh_client.login()

    context = AppContext(
        telegram_app=telegram_app,
        chat_id=settings.telegram_chat_id,
        db_conn=db_conn,
        news_scraper=news_scraper,
        market_data_client=market_data_client,
        rh_client=rh_client,
        prop_client=prop_client,
        router=router,
        sheets_ledger=sheets_ledger,
    )

    premarket_service = PremarketService(
        telegram_app=context.telegram_app,
        chat_id=context.chat_id,
        repo=trade_repo,
        news_scraper=context.news_scraper,
        market_data_client=context.market_data_client,
        router=context.router,
    )
    midday_service = MiddayService(
        telegram_app=context.telegram_app,
        chat_id=context.chat_id,
        repo=trade_repo,
        news_scraper=context.news_scraper,
        rh_client=context.rh_client,
        prop_client=context.prop_client,
    )
    postmarket_service = PostmarketService(
        telegram_app=context.telegram_app,
        chat_id=context.chat_id,
        repo=trade_repo,
        news_scraper=context.news_scraper,
    )

    scheduler = build_scheduler(
        timezone=settings.timezone,
        premarket_service=premarket_service,
        midday_service=midday_service,
        postmarket_service=postmarket_service,
    )

    stop_event = asyncio.Event()

    def _request_shutdown(*_) -> None:
        logger.info("Shutdown signal received.")
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _request_shutdown)
        except NotImplementedError:
            signal.signal(sig, lambda *_: _request_shutdown())

    logger.info("Initializing Telegram bot...")
    await telegram_app.initialize()
    await telegram_app.start()
    await telegram_app.updater.start_polling()

    logger.info("Starting scheduler...")
    scheduler.start()

    logger.info("Bot is live. Waiting for scheduled jobs and Telegram events.")
    try:
        await stop_event.wait()
    finally:
        logger.info("Shutting down scheduler...")
        scheduler.shutdown(wait=False)

        logger.info("Stopping Telegram updater...")
        await telegram_app.updater.stop()

        logger.info("Stopping Telegram application...")
        await telegram_app.stop()
        await telegram_app.shutdown()

        logger.info("Closing clients and database...")
        await news_scraper.close()
        await market_data_client.close()
        await prop_client.close()
        rh_client.logout()
        db_conn.close()

        logger.info("Application shutdown complete.")


if __name__ == "__main__":
    try:
        asyncio.run(run_app())
    except KeyboardInterrupt:
        logger.info("Application interrupted by user.")
