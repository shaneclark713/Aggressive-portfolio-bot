from html import escape
from typing import Any, Dict, Sequence


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def format_trade_alert(payload: Dict[str, Any]) -> str:
    symbol = escape(str(payload.get("symbol", "UNKNOWN")))
    strategy = escape(str(payload.get("strategy", "Unknown Strategy")))
    side = str(payload.get("side", "LONG")).upper()
    horizon = escape(str(payload.get("trade_horizon", "DAY_TRADE")))
    holding_style = escape(str(payload.get("holding_style", "Intraday")))

    entry = _to_float(payload.get("entry_price"))
    sl = _to_float(payload.get("stop_loss"))
    tp = _to_float(payload.get("take_profit"))
    rr_ratio = _to_float(payload.get("rr_ratio"))
    risk = _to_float(payload.get("risk_per_share"))
    reward = _to_float(payload.get("reward_per_share"))

    direction_emoji = "🟢 LONG" if side == "LONG" else "🔴 SHORT"
    alert_title = f"🚨 <b>TRADE ALERT: {symbol}</b> 🚨"

    message = f"""
{alert_title}
<b>Strategy:</b> {strategy}
<b>Direction:</b> {direction_emoji}
<b>Horizon:</b> {horizon} ({holding_style})

<b>Execution Levels:</b>
• <b>Entry:</b> ${entry:.2f}
• <b>Target (TP):</b> ${tp:.2f} 🎯
• <b>Invalidation (SL):</b> ${sl:.2f} 🛡️

<b>Risk Math:</b>
• <b>Risk Per Share:</b> ${risk:.2f}
• <b>Reward Per Share:</b> ${reward:.2f}
• <b>R:R Ratio:</b> 1 : {rr_ratio:.2f} ⚖️

<i>Awaiting your command...</i>
"""
    return message.strip()


def format_daily_report(title: str, bullets: Sequence[str]) -> str:
    safe_title = escape(title)
    bullet_text = "\n".join(f"• {escape(str(item))}" for item in bullets)
    return f"📊 <b>{safe_title}</b>\n\n{bullet_text}"
