import logging
from typing import List, Tuple

import pandas as pd
import pandas_ta as ta

logger = logging.getLogger("aggressive_portfolio_bot.risk.kill_switch")


class AntiFomoKillSwitch:
    def __init__(self):
        self.max_ema_extension_pct = 0.03
        self.rsi_boiling_point = 80
        self.elevator_candle_count = 4
        self.atr_blowoff_multiplier = 3.0
        self.volume_spike_multiplier = 2.0

    def check_trade_validity(self, df: pd.DataFrame, symbol: str, side: str = "LONG") -> Tuple[bool, str]:
        if side.upper() != "LONG":
            return True, "Passed (Not a Long Entry)"

        required_cols: List[str] = ["open", "high", "low", "close", "volume"]
        missing = [col for col in required_cols if col not in df.columns]
        if missing:
            return False, f"Missing required columns: {missing}"

        if len(df) < 21:
            return False, "Insufficient data for FOMO indicators"

        work_df = df[required_cols].copy()
        work_df.ta.ema(length=9, append=True)
        work_df.ta.rsi(length=14, append=True)
        work_df.ta.bbands(length=20, std=2, append=True)
        work_df.ta.atr(length=14, append=True)

        latest = work_df.iloc[-1]
        close_price = float(latest["close"])
        high_price = float(latest["high"])
        low_price = float(latest["low"])
        current_volume = float(latest["volume"])

        ema_9 = latest.get("EMA_9")
        rsi_14 = latest.get("RSI_14")
        upper_bb = latest.get("BBU_20_2.0")
        atr_14 = latest.get("ATR_14")

        if pd.isna(ema_9) or pd.isna(rsi_14) or pd.isna(upper_bb) or pd.isna(atr_14):
            return False, "Indicator values unavailable"

        avg_volume = work_df["volume"].rolling(window=20).mean().iloc[-1]
        if pd.isna(avg_volume) or avg_volume <= 0:
            return False, "Average volume unavailable"

        candle_size = high_price - low_price

        if ema_9 <= 0:
            return False, "Invalid EMA value"

        extension_pct = (close_price - ema_9) / ema_9
        if extension_pct > self.max_ema_extension_pct:
            logger.warning("FOMO KILL: %s Rubber Band triggered (%.2f%% above EMA9).", symbol, extension_pct * 100)
            return False, "Rubber Band Extension"

        if rsi_14 > self.rsi_boiling_point and close_price > upper_bb:
            logger.warning("FOMO KILL: %s Boiling Point triggered (RSI %.1f, above upper BB).", symbol, rsi_14)
            return False, "Boiling Point Exhaustion"

        if atr_14 > 0 and candle_size > (atr_14 * self.atr_blowoff_multiplier) and current_volume > (avg_volume * self.volume_spike_multiplier):
            logger.warning("FOMO KILL: %s Blow-Off Top triggered.", symbol)
            return False, "Blow-Off Top Reversal Risk"

        consecutive_green = 0
        for i in range(1, self.elevator_candle_count + 1):
            c_row = work_df.iloc[-i]
            c_open = float(c_row["open"])
            c_close = float(c_row["close"])
            c_high = float(c_row["high"])
            c_low = float(c_row["low"])

            c_range = c_high - c_low
            if c_range <= 0:
                break

            closes_near_high = c_close >= (c_low + 0.70 * c_range)
            is_green = c_close > c_open

            if is_green and closes_near_high:
                consecutive_green += 1
            else:
                break

        if consecutive_green >= self.elevator_candle_count:
            logger.warning("FOMO KILL: %s Elevator triggered (%s consecutive strong green candles).", symbol, consecutive_green)
            return False, "Elevator Move Exhaustion"

        return True, "Passed"
