from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def build_trade_keyboard(trade_id: str) -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton("✅ Approve (Live)", callback_data=f"a|{trade_id}"),
            InlineKeyboardButton("📝 Paper Trade", callback_data=f"p|{trade_id}"),
        ],
        [
            InlineKeyboardButton("❌ Reject", callback_data=f"r|{trade_id}")
        ],
    ]
    return InlineKeyboardMarkup(keyboard)
