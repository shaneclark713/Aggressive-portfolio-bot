import json
class SettingsRepository:
    def __init__(self, conn): self.conn=conn
    def get(self, key: str, default=None):
        row=self.conn.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
        if not row: return default
        try: return json.loads(row['value'])
        except Exception: return row['value']
    def set(self, key: str, value): self.conn.execute('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=CURRENT_TIMESTAMP',(key,json.dumps(value))); self.conn.commit()
    def get_active_preset(self): return self.get('active_preset','day_trade_momentum')
    def set_active_preset(self, preset): self.set('active_preset',preset)
    def get_execution_mode(self): return self.get('execution_mode',None)
    def set_execution_mode(self, mode): self.set('execution_mode',mode)
    def get_filter_overrides(self): return self.get('filter_overrides',{}) or {}
    def set_filter_override(self, section,key,value):
        overrides=self.get_filter_overrides(); overrides.setdefault(section,{})[key]=value; self.set('filter_overrides',overrides)
    def clear_filter_override(self, section,key):
        overrides=self.get_filter_overrides(); overrides.get(section,{}).pop(key,None); self.set('filter_overrides',overrides)
    def get_strategy_states(self):
        rows=self.conn.execute('SELECT strategy, enabled FROM strategy_states').fetchall(); return {r['strategy']: bool(r['enabled']) for r in rows}
    def set_strategy_state(self, strategy, enabled): self.conn.execute('INSERT INTO strategy_states (strategy, enabled) VALUES (?,?) ON CONFLICT(strategy) DO UPDATE SET enabled=excluded.enabled',(strategy,int(enabled))); self.conn.commit()
