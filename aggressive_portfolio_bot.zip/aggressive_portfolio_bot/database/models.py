from dataclasses import dataclass
from typing import Optional
@dataclass(slots=True)
class TradeRecord:
    trade_id: str; broker: str; broker_order_id: Optional[str]; symbol: str; side: str; strategy: str; horizon: str; instrument_type: str; status: str; entry_time: Optional[str]; exit_time: Optional[str]; entry_price: Optional[float]; exit_price: Optional[float]; stop_loss: Optional[float]; take_profit: Optional[float]; pnl: Optional[float]; rr_ratio: Optional[float]; close_reason: Optional[str]; entry_snapshot_path: Optional[str]; close_snapshot_path: Optional[str]; notes: Optional[str]
