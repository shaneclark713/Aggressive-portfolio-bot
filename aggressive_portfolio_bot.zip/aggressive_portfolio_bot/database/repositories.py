import json
class TradeRepository:
    def __init__(self, conn): self.conn=conn
    def upsert_trade(self, payload: dict) -> None:
        keys=list(payload.keys()); placeholders=', '.join(['?']*len(keys)); updates=', '.join([f"{k}=excluded.{k}" for k in keys if k!='trade_id']) + ', updated_at=CURRENT_TIMESTAMP'
        sql=f"INSERT INTO trades ({', '.join(keys)}) VALUES ({placeholders}) ON CONFLICT(trade_id) DO UPDATE SET {updates}"
        self.conn.execute(sql,[payload[k] for k in keys]); self.conn.commit()
    def get_trade(self, trade_id: str): return self.conn.execute('SELECT * FROM trades WHERE trade_id=?',(trade_id,)).fetchone()
    def get_open_trades(self): return self.conn.execute("SELECT * FROM trades WHERE status IN ('OPEN','PARTIAL','LIVE_SENT','APPROVED') ORDER BY created_at DESC").fetchall()
    def get_bot_positions_for_symbol(self, symbol: str): return self.conn.execute("SELECT * FROM trades WHERE symbol=? AND status IN ('OPEN','PARTIAL','LIVE_SENT')",(symbol.upper(),)).fetchall()
class AlertRepository:
    def __init__(self, conn): self.conn=conn
    def create_alert(self, trade_id,symbol,strategy,side,execution_mode,expires_at): self.conn.execute('INSERT OR REPLACE INTO alerts (trade_id,symbol,strategy,side,execution_mode,status,expires_at) VALUES (?,?,?,?,?,?,?)',(trade_id,symbol,strategy,side,execution_mode,'PENDING_ALERT',expires_at)); self.conn.commit()
    def set_message_id(self, trade_id, message_id): self.conn.execute('UPDATE alerts SET message_id=? WHERE trade_id=?',(message_id,trade_id)); self.conn.commit()
    def update_status(self, trade_id, status): self.conn.execute('UPDATE alerts SET status=? WHERE trade_id=?',(status,trade_id)); self.conn.commit()
    def get_pending_alert(self, trade_id): return self.conn.execute('SELECT * FROM alerts WHERE trade_id=?',(trade_id,)).fetchone()
    def get_expired_alerts(self): return self.conn.execute("SELECT * FROM alerts WHERE status='PENDING_ALERT' AND expires_at <= CURRENT_TIMESTAMP").fetchall()
class ExecutionLogRepository:
    def __init__(self, conn): self.conn=conn
    def log(self, action: str, trade_id=None, actor_chat_id=None, details=None): self.conn.execute('INSERT INTO execution_logs (trade_id,action,actor_chat_id,details) VALUES (?,?,?,?)',(trade_id,action,actor_chat_id,json.dumps(details or {}))); self.conn.commit()
