import logging
from typing import Any, Dict, Type

import backtrader as bt
import pandas as pd

logger = logging.getLogger("aggressive_portfolio_bot.sandbox.backtrader_engine")


class SandboxAnalyzer(bt.Analyzer):
    def create_analysis(self):
        self.rets = {
            "total_trades": 0,
            "wins": 0,
            "losses": 0,
            "win_rate_pct": 0.0,
            "net_pnl": 0.0,
        }

    def notify_trade(self, trade):
        if trade.isclosed:
            self.rets["total_trades"] += 1
            self.rets["net_pnl"] += trade.pnlcomm
            if trade.pnlcomm > 0:
                self.rets["wins"] += 1
            else:
                self.rets["losses"] += 1

    def get_analysis(self):
        total = self.rets["total_trades"]
        self.rets["win_rate_pct"] = round((self.rets["wins"] / total * 100) if total > 0 else 0.0, 2)
        self.rets["net_pnl"] = round(self.rets["net_pnl"], 2)
        return self.rets


class BacktestEngine:
    def __init__(self):
        self.cerebro = bt.Cerebro()

    def run_historical_probability(self, strategy_class: Type[bt.Strategy], df: pd.DataFrame) -> Dict[str, Any]:
        if df.empty:
            logger.warning("Empty DataFrame provided to BacktestEngine.")
            return {}

        required_cols = {"open", "high", "low", "close", "volume"}
        if not required_cols.issubset(df.columns):
            logger.warning("DataFrame missing required OHLCV columns.")
            return {}

        logger.info("Initializing historical sandbox environment...")
        work_df = df.copy().sort_index()

        data_feed = bt.feeds.PandasData(
            dataname=work_df,
            datetime=None,
            open="open",
            high="high",
            low="low",
            close="close",
            volume="volume",
            openinterest=None,
        )

        self.cerebro = bt.Cerebro()
        self.cerebro.adddata(data_feed)
        self.cerebro.addstrategy(strategy_class)
        self.cerebro.broker.setcash(10000.0)
        self.cerebro.addanalyzer(SandboxAnalyzer, _name="sandbox_stats")

        try:
            results = self.cerebro.run()
            if not results:
                logger.warning("Backtest returned no strategy results.")
                return {}

            first_strategy = results[0]
            stats = first_strategy.analyzers.sandbox_stats.get_analysis()
            logger.info("Backtest complete. Win Rate: %s%%", stats.get("win_rate_pct", 0.0))
            return stats
        except Exception as e:
            logger.exception("Backtest engine failed during execution: %s", e)
            return {}
