import logging
from typing import Any, Dict

logger = logging.getLogger("aggressive_portfolio_bot.risk.risk_engine")


class RiskEngine:
    def __init__(self, min_rr_ratio: float = 2.0, atr_multiplier_sl: float = 1.0):
        self.min_rr_ratio = min_rr_ratio
        self.atr_multiplier_sl = atr_multiplier_sl

    def calculate_trade_parameters(
        self,
        symbol: str,
        entry_price: float,
        side: str,
        atr: float,
        recent_swing_high: float,
        recent_swing_low: float,
    ) -> Dict[str, Any]:
        side = side.upper()

        numeric_values = {
            "entry_price": entry_price,
            "atr": atr,
            "recent_swing_high": recent_swing_high,
            "recent_swing_low": recent_swing_low,
        }

        for name, value in numeric_values.items():
            if value is None or value <= 0:
                logger.warning("Invalid %s for %s: %s", name, symbol, value)
                return {"is_valid": False, "reason": f"Invalid {name}"}

        if recent_swing_low >= recent_swing_high:
            return {"is_valid": False, "reason": "Invalid swing structure"}

        if side == "LONG":
            stop_loss = recent_swing_low - (atr * self.atr_multiplier_sl)
            take_profit = recent_swing_high
            risk = entry_price - stop_loss
            reward = take_profit - entry_price
        elif side == "SHORT":
            stop_loss = recent_swing_high + (atr * self.atr_multiplier_sl)
            take_profit = recent_swing_low
            risk = stop_loss - entry_price
            reward = entry_price - take_profit
        else:
            return {"is_valid": False, "reason": "Invalid side"}

        if risk <= 0:
            return {"is_valid": False, "reason": "Invalid risk math"}
        if reward <= 0:
            return {"is_valid": False, "reason": "No logical structural reward"}

        actual_rr = reward / risk
        is_valid = actual_rr >= self.min_rr_ratio

        return {
            "symbol": symbol,
            "side": side,
            "entry_price": round(entry_price, 2),
            "stop_loss": round(stop_loss, 2),
            "take_profit": round(take_profit, 2),
            "risk": round(risk, 2),
            "reward": round(reward, 2),
            "actual_rr": round(actual_rr, 2),
            "required_rr": round(self.min_rr_ratio, 2),
            "is_valid": is_valid,
            "reason": "Passed" if is_valid else f"Poor structural R:R ({actual_rr:.2f})",
        }
