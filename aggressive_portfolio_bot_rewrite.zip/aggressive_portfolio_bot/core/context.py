from dataclasses import dataclass
from typing import Any


@dataclass
class AppContext:
    telegram_app: Any
    chat_id: str
    db_conn: Any
    news_scraper: Any
    market_data_client: Any
    rh_client: Any
    prop_client: Any
    router: Any
    sheets_ledger: Any | None = None
