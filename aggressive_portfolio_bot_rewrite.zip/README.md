# Aggressive Portfolio Bot Rewrite

This package contains a final integration rewrite pass for the custom asynchronous trading bot scaffold.

Included upgrades:
- shared async client lifecycle patterns
- HTML Telegram formatting
- compact callback payloads using trade IDs
- repository layer for SQLite
- cleaned strategy router and service orchestration
- safer broker/data wrappers
- Google Sheets ledger improvements
- Backtrader sandbox cleanup
