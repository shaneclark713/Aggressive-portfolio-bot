import logging
from typing import List

from aggressive_portfolio_bot.database.repositories import TradeRepository
from aggressive_portfolio_bot.telegram_bot.formatters import format_daily_report

logger = logging.getLogger("aggressive_portfolio_bot.services.postmarket")


class PostmarketService:
    def __init__(self, telegram_app, chat_id: str, repo: TradeRepository, news_scraper):
        self.telegram_app = telegram_app
        self.chat_id = chat_id
        self.repo = repo
        self.news_scraper = news_scraper

    async def run(self) -> None:
        logger.info("Initiating 9:00 PM Post-Market Workflow...")
        bullets: List[str] = []

        headlines = await self.news_scraper.fetch_market_news()
        sentiment_data = self.news_scraper.analyze_sentiment(headlines)
        market_sentiment = sentiment_data.get("sentiment", "Neutral")
        bullets.append(f"After-Hours Sentiment: {market_sentiment}")

        db_trades = self.repo.get_open_trades()
        if not db_trades:
            bullets.append("Open Plays: No active bot-managed trades to review.")
        else:
            bullets.append("Open Plays (Technical Close Check):")
            for trade in db_trades:
                bullets.append(
                    f"{trade.symbol} ({trade.side}) | Entry: ${trade.entry_price:.2f} | "
                    f"SL: ${trade.stop_loss:.2f} | TP: ${trade.take_profit:.2f} | "
                    "Review daily candle structure for overnight holding risk."
                )

        bullets.append("Next-Day Scouting:")
        bullets.append("Initiating broader market screen for tomorrow's potential watchlists.")

        report_text = format_daily_report(title="🌙 9:00 PM End of Day Wrap-Up", bullets=bullets)
        await self.telegram_app.bot.send_message(
            chat_id=self.chat_id,
            text=report_text,
            parse_mode="HTML",
        )
        logger.info("Post-Market Report sent to Telegram.")
