import aiohttp
import logging
from typing import Optional

import pandas as pd

logger = logging.getLogger("aggressive_portfolio_bot.data.market_data")


class MarketDataClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.polygon.io/v2"
        self.session: Optional[aiohttp.ClientSession] = None
        self.timeout = aiohttp.ClientTimeout(total=15)

    async def connect(self) -> None:
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(timeout=self.timeout)

    async def close(self) -> None:
        if self.session and not self.session.closed:
            await self.session.close()
        self.session = None

    def _is_ready(self) -> bool:
        return self.session is not None and not self.session.closed

    async def get_historical_data(
        self,
        symbol: str,
        multiplier: int = 5,
        timespan: str = "minute",
        start_date: str = "2024-01-01",
        end_date: str = "2024-12-31",
    ) -> pd.DataFrame:
        if not self._is_ready():
            logger.warning("MarketDataClient session is not initialized.")
            return pd.DataFrame()

        endpoint = f"{self.base_url}/aggs/ticker/{symbol}/range/{multiplier}/{timespan}/{start_date}/{end_date}"
        params = {
            "adjusted": "true",
            "sort": "asc",
            "apiKey": self.api_key,
        }

        try:
            async with self.session.get(endpoint, params=params) as response:
                if response.status != 200:
                    logger.error("Failed to fetch data for %s. HTTP %s", symbol, response.status)
                    return pd.DataFrame()

                data = await response.json()
                results = data.get("results")
                if not isinstance(results, list) or not results:
                    logger.warning("No market data found for %s.", symbol)
                    return pd.DataFrame()

                df = pd.DataFrame(results).rename(
                    columns={
                        "v": "volume",
                        "vw": "vwap",
                        "o": "open",
                        "c": "close",
                        "h": "high",
                        "l": "low",
                        "t": "timestamp",
                        "n": "transactions",
                    }
                )

                if "timestamp" not in df.columns:
                    logger.warning("Timestamp missing for %s.", symbol)
                    return pd.DataFrame()

                df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
                df = df.set_index("datetime").sort_index()

                wanted = ["open", "high", "low", "close", "volume", "vwap", "transactions", "timestamp"]
                existing = [col for col in wanted if col in df.columns]
                df = df[existing].copy()

                for col in ["open", "high", "low", "close", "volume", "vwap"]:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors="coerce")

                return df.dropna(subset=["open", "high", "low", "close"])
        except Exception as e:
            logger.exception("Network exception fetching market data for %s: %s", symbol, e)
            return pd.DataFrame()

    async def get_latest_price(self, symbol: str) -> Optional[float]:
        if not self._is_ready():
            logger.warning("MarketDataClient session is not initialized.")
            return None

        endpoint = f"{self.base_url}/snapshot/locale/us/markets/stocks/tickers/{symbol}"
        params = {"apiKey": self.api_key}

        try:
            async with self.session.get(endpoint, params=params) as response:
                if response.status != 200:
                    logger.warning("Failed to fetch snapshot for %s. HTTP %s", symbol, response.status)
                    return None

                data = await response.json()
                ticker = data.get("ticker", {})
                last_trade = ticker.get("lastTrade", {})
                price = last_trade.get("p")
                if price is None:
                    minute_bar = ticker.get("min", {})
                    price = minute_bar.get("c")
                return float(price) if price is not None else None
        except Exception as e:
            logger.exception("Error fetching snapshot for %s: %s", symbol, e)
            return None
