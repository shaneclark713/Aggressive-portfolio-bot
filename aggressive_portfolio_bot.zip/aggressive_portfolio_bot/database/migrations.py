def run_migrations(conn) -> None:
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS strategy_states (strategy TEXT PRIMARY KEY, enabled INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS trades (
            trade_id TEXT PRIMARY KEY, broker TEXT NOT NULL, broker_order_id TEXT, symbol TEXT NOT NULL, side TEXT NOT NULL, strategy TEXT NOT NULL, horizon TEXT NOT NULL, instrument_type TEXT NOT NULL, status TEXT NOT NULL,
            entry_time TEXT, exit_time TEXT, entry_price REAL, exit_price REAL, stop_loss REAL, take_profit REAL, pnl REAL, rr_ratio REAL, close_reason TEXT, entry_snapshot_path TEXT, close_snapshot_path TEXT, notes TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS alerts (
            trade_id TEXT PRIMARY KEY, symbol TEXT NOT NULL, strategy TEXT NOT NULL, side TEXT NOT NULL, execution_mode TEXT NOT NULL, message_id INTEGER, status TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, expires_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS execution_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, trade_id TEXT, action TEXT NOT NULL, actor_chat_id TEXT, details TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    ''')
    conn.commit()
