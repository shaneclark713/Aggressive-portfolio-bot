import logging
from typing import Any, Dict, List

import pandas as pd
import pandas_ta as ta

logger = logging.getLogger("aggressive_portfolio_bot.strategies.mean_reversion")


class MeanReversionStrategy:
    def __init__(self, rsi_oversold: int = 30, rsi_overbought: int = 70):
        self.rsi_oversold = rsi_oversold
        self.rsi_overbought = rsi_overbought

    def analyze(self, df: pd.DataFrame, symbol: str) -> Dict[str, Any]:
        required_cols: List[str] = ["open", "high", "low", "close"]
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            return {"symbol": symbol, "signal": "INVALID_DATA", "reason": f"Missing columns: {missing_cols}"}

        work_df = df[required_cols].dropna().copy()
        if len(work_df) < 21:
            return {"symbol": symbol, "signal": "INSUFFICIENT_DATA"}

        work_df.ta.bbands(length=20, std=2, append=True)
        work_df.ta.rsi(length=14, append=True)

        prev_candle = work_df.iloc[-2]
        current_candle = work_df.iloc[-1]

        current_close = float(current_candle["close"])
        current_open = float(current_candle["open"])
        current_rsi = current_candle.get("RSI_14")
        prev_close = float(prev_candle["close"])
        prev_low = float(prev_candle["low"])
        prev_high = float(prev_candle["high"])

        prev_lower_bb = prev_candle.get("BBL_20_2.0")
        prev_upper_bb = prev_candle.get("BBU_20_2.0")
        mid_bb = current_candle.get("BBM_20_2.0")

        if pd.isna(current_rsi) or pd.isna(prev_lower_bb) or pd.isna(prev_upper_bb) or pd.isna(mid_bb):
            return {"symbol": symbol, "signal": "INVALID_DATA", "reason": "Indicator values unavailable"}

        signal = "WAIT"
        if prev_low < prev_lower_bb and current_rsi < self.rsi_oversold:
            if current_close > current_open and current_close > prev_close:
                signal = "LONG_REVERSION"
        elif prev_high > prev_upper_bb and current_rsi > self.rsi_overbought:
            if current_close < current_open and current_close < prev_close:
                signal = "SHORT_REVERSION"

        return {
            "symbol": symbol,
            "signal": signal,
            "mean_target": round(float(mid_bb), 2),
            "current_rsi": round(float(current_rsi), 2),
            "current_close": round(current_close, 2),
            "reversion_confirmed": signal != "WAIT",
        }
