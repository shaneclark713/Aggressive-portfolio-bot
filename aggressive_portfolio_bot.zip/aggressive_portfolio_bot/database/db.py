import sqlite3
from pathlib import Path

def connect_db(storage_path: Path) -> sqlite3.Connection:
    storage_path.mkdir(parents=True, exist_ok=True)
    db_path = storage_path / 'trading_bot.sqlite3'
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn
